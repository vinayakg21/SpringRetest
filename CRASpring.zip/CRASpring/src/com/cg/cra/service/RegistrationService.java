package com.cg.cra.service;

import java.util.List;

import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;

public interface RegistrationService {

	long insertRegistration(Registration reg);
	List<Course> getAllCourses();
	Registration getAllStudents(Integer regId);
	void deleteStudents(Integer regId);
	void updateStudent(Registration reg);
}
