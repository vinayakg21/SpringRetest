package com.cg.cra.dao;

import java.util.List;

import com.cg.cra.entity.Registration;
import com.cg.cra.entity.Course;
public interface RegistrationDao {

	long insertRegistartion(Registration reg);
	List<Course> getAllCourses();
	Registration getAllStudents(Integer regId);
	void deleteStudents(Integer regId);
}
